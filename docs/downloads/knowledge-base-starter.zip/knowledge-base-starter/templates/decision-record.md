# Decision: [title]

- Date:
- Status: proposed | accepted | superseded
- Decision owner:
- Participants:
- Context:
- Options considered:
- Decision:
- Rationale:
- Risks and tradeoffs:
- Follow-up actions:
- Evidence:
- Review trigger:
- Superseded by:
