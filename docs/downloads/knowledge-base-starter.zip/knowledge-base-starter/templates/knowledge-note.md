---
title:
type:
status: draft
source-id:
source-url:
source-type:
author-or-owner:
published-or-effective-date:
accessed-date:
owner:
created:
review-by:
tags: []
supersedes:
superseded-by:
---

# Summary

# Confirmed information

# Interpretation or implications

# Procedure or actions

# Limitations and uncertainty

# Related notes

# Source locations
