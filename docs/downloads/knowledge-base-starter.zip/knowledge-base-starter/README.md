# Knowledge-base starter

## Purpose

Describe what this collection helps people do.

## Intended users

## Included topics

## Excluded topics

## Authoritative source types

## Approval statuses
- `draft`: created or changed but not reviewed;
- `reviewed`: checked by the assigned reviewer;
- `approved`: authoritative for the defined use;
- `superseded`: replaced by newer material;
- `archived`: retained for history but not current.

## Who can approve notes

## Review schedule

## Sensitive information rules

## How to report corrections
