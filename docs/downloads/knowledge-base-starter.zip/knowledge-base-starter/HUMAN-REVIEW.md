# Human review

- [ ] The source is approved and traceable.
- [ ] The note location is appropriate.
- [ ] Confirmed information is separated from interpretation.
- [ ] Important claims include source locations.
- [ ] Owner, status, and review date are present.
- [ ] Proposed links point to real and useful targets.
- [ ] Duplicates and conflicts were checked.
- [ ] Sensitive information is handled correctly.
- [ ] The note remains draft until a person approves it.
- [ ] No unrelated files or .obsidian/ settings were changed.
