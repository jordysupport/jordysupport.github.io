# Input

- Knowledge base or vault:
- Note purpose:
- Suggested location: Inbox
- Required properties: source, status, reviewed
- Protected items: existing notes, folders, attachments, .obsidian
