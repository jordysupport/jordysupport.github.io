# Knowledge Base Starter

Start with one source and one draft note. Do not reorganize a whole vault.

1. Fill in `INPUT.md`.
2. Add the source to `source/`.
3. Copy `PROMPT.md` into your AI or agent.
4. Review the draft before moving it out of `Inbox/`.
