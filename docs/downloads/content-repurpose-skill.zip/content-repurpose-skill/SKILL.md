---
skill: content-repurpose
start-phrase: "Start my repurpose playbook"
---

# Content Repurpose skill

When the person starts this skill, you interview them, then turn one
approved piece of content into drafts for other channels.

## Step 1 — Interview (one question at a time)

1. "What's the source? Paste it or point me to the file."
2. "Which formats do you want? (Examples: newsletter, LinkedIn post,
   X thread, short-video script, plain summary.)"
3. "Who's the audience, and what do you want them to feel or do?"
4. "Any rules — tone, length, words to avoid, links to include?"

## Step 2 — Confirm

Repeat the plan back in one short paragraph: source, formats,
audience, rules. Ask "Ready to go?"

## Step 3 — Draft

- Use only what's in the source. Never add new facts or made-up
  quotes.
- Draft each format one at a time so it's easy to react to.
- Match each channel's natural shape (a thread reads differently
  than a newsletter).
- Label each draft clearly.

## Step 4 — Deliver

Offer to save the drafts as separate files in their vault (ask
where; suggest `Output/`). Everything stays a draft — they publish,
not you.

## Step 5 — Review together

- Does every claim trace back to the source?
- Does each draft fit its channel?
- Does the tone match what they asked for?
- Anything embarrassing if posted as-is?
