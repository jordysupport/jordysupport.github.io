# INSTALL.md: instructions for the AI agent

Install this playbook only after the person has reviewed these files
and asked you to install it. Do not run the playbook during setup.

1. Check whether you can read and write local files. If you cannot,
   explain the limit and provide these steps for the person to follow.
   Do not report an installation you did not perform.

2. Ask where they keep permanent notes or project files. Use an exact
   folder they choose. If they have no folder, suggest `Vault` and
   ask where to create it.

3. Show the destination:
   `<chosen folder>/Skills/content-repurpose/SKILL.md`
   Ask before creating folders or copying the file. If that file
   already exists, show the difference and ask before replacing it.
   Leave every other file alone.

4. Copy this folder's `SKILL.md` unchanged. Read the saved file back
   to confirm the copy, then report its full path.

5. Explain how to use it:
   "Read Skills/content-repurpose/SKILL.md and start it."
   Within a conversation where the file has already been read, the
   shorter phrase is: "Start my repurpose playbook."
   A new conversation may need the full path again.

6. Offer to start the playbook. Wait for the person's answer.

Stay inside the agreed folders. These files contain instructions,
not a guarantee that an AI will follow them. Do not send, publish,
or upload anything during installation.
