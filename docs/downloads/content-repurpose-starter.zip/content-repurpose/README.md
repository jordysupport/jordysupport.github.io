# Content Repurposing Starter

1. Put the approved source in `SOURCE.md`.
2. Fill in `INPUT.md`.
3. Copy `PROMPT.md` into your AI.
4. Save and review drafts in `output/`.
