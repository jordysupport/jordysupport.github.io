# Review

- [ ] Claims came from the source.
- [ ] Each format fits its channel.
- [ ] Voice and call to action are accurate.
- [ ] Names, links, dates, and quotations were checked.
