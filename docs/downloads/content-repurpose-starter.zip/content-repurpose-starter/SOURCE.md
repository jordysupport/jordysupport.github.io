# Source identity

- Title:
- Owner:
- Approved date:
- Canonical URL if published:
- Intended audience:

# Source content

[paste the source or reference an approved file]

# Approved claims
-

# Claims requiring exact wording or qualification
-

# Prohibited or unsupported claims
-

# Required links or disclosures
-

# Private or internal details that must not appear
-
