# Run record

- Playbook: Content repurposing
- Date:
- Operator:
- Source version:
- Content specification version:
- Drafts created:
- Audit results:
- Human corrections:
- Publication or schedule actions:
- Warnings or unresolved questions:
- Final status:
