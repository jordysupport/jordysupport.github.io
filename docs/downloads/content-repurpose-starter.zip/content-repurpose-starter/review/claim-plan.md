# Claim and format plan

## Core message

## Approved claims

| Claim ID | Approved claim | Source location | May paraphrase? | Required qualification | Allowed formats |
|---|---|---|---|---|---|
| C01 |  |  | Yes / No |  |  |

## Format assignments

### Format 1
- Central message:
- Reader action:
- Claim IDs:
- Structure:
- Omissions:
- Needs-approval ideas:

### Format 2
- Central message:
- Reader action:
- Claim IDs:
- Structure:
- Omissions:
- Needs-approval ideas:
