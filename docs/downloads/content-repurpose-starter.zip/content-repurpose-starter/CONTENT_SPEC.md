# Content specification

## Format 1
- Name:
- Audience:
- Objective:
- Length:
- Required structure:
- Reader action:
- Voice rules:
- Required links:
- Prohibited content:

## Format 2
- Name:
- Audience:
- Objective:
- Length:
- Required structure:
- Reader action:
- Voice rules:
- Required links:
- Prohibited content:
