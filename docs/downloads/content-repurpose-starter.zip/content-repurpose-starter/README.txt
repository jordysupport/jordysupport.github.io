CONTENT REPURPOSING STARTER

1. Put one approved source and its allowed claims in SOURCE.md.
2. Define every requested format in CONTENT_SPEC.md.
3. Start your AI agent inside this folder, or paste REPURPOSE-PROMPT.txt into a chat.
4. Review review/claim-plan.md before drafting.
5. Review every file in drafts/.
6. Run AUDIT-PROMPT.txt.
7. A person approves the exact final version before publishing or scheduling.

Do not use this workflow to manufacture claims, experiences, testimonials, urgency, promises, or evidence.
