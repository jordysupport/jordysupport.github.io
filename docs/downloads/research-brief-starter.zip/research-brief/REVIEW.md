# Review

- [ ] Important claims have working sources.
- [ ] Dates are visible where needed.
- [ ] Facts and recommendations are separated.
- [ ] Unknowns are stated.
- [ ] The conclusion answers the question.
