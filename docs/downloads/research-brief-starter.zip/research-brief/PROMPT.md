Create a source-backed research brief using INPUT.md.

Start with a short research plan. Cite important factual claims, separate facts from inferences, flag uncertainty, and never pretend a source was checked. Output an executive summary, findings, risks or unknowns, implications, and sources.
