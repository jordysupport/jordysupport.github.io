# Research Brief Starter

1. Fill in `INPUT.md`.
2. Copy `PROMPT.md` into your AI.
3. Save the answer in `output/BRIEF.md`.
4. Complete `REVIEW.md`.
