# Run record

- Playbook: Research brief
- Date:
- Operator:
- Question version:
- Source files or URLs:
- Actions performed:
- Outputs created:
- Validation results:
- Human corrections:
- Warnings or unresolved questions:
- Final status:
