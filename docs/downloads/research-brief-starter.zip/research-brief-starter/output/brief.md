# [Research topic]

## Decision and scope

## Executive summary
Maximum 200 words. State the most decision-relevant findings, uncertainty, and what not to conclude.

## Key findings

### Finding 1
- Finding:
- Why it matters:
- Evidence:
- Confidence:
- Limitations:

## Comparison or evidence table

## Conflicting evidence and uncertainty

## Implications
Separate evidence-backed implications from recommendations.

## Recommended next questions or tests

## Sources
