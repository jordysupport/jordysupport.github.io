# Source notes

## Source ID: S01

- Title:
- Publisher or author:
- URL:
- Source type: primary / secondary / community
- Publication date:
- Event or data date:
- Accessed date:
- Scope and relevance:
- Important claims:
- Supporting section, page, or timestamp:
- Limitations or incentives:
- Conflicts with other sources:
