# Research question

## Decision this supports
What will the reader decide or do differently?

## Primary question

## Subquestions
1.
2.
3.

## Audience

## Scope
- Geography:
- Time period:
- Included:
- Excluded:

## Source policy
- Preferred primary sources:
- Acceptable secondary sources:
- Excluded sources:
- Maximum age for time-sensitive claims:

## Required output

## Deadline
