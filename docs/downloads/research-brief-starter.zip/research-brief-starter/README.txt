RESEARCH BRIEF STARTER

1. Fill in QUESTION.md.
2. Put any approved source files or notes in sources/.
3. Start your AI agent inside this folder, or paste RESEARCH-PROMPT.txt into a chat.
4. Review the source plan before research begins.
5. Review output/evidence-table.csv before the final brief is drafted.
6. Run FACT-AUDIT-PROMPT.txt against the final brief.
7. A person reviews the exact final output.

The AI should not send, publish, purchase, delete, or modify external systems.
