# Input

- Meeting and date:
- Purpose:
- Participants:
- Output audience:
- Follow-up tone:
