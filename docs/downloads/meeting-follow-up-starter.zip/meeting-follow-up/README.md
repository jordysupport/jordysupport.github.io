# Meeting Follow-up Starter

1. Fill in `INPUT.md`.
2. Add approved notes or a transcript to `MEETING.md`.
3. Copy `PROMPT.md` into your AI.
4. Review every decision, owner, and deadline.
