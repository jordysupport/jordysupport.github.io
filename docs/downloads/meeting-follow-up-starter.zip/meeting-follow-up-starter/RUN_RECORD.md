# Run record

- Playbook: Meeting follow-up
- Date:
- Operator:
- Meeting source:
- Permission or consent check:
- Outputs created:
- Human corrections:
- External actions:
- Warnings or unresolved questions:
- Final status:
