# Meeting context

- Meeting title:
- Date and timezone:
- Purpose:
- Participants and roles:
- Project:
- Approved source files:
- Known terminology:
- Sensitive topics to minimize or exclude:
- Follow-up audience:
- Sending is allowed: No
