# Decision log

| Decision | Date | Decision owner or group | Evidence | Impact | Follow-up needed |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
