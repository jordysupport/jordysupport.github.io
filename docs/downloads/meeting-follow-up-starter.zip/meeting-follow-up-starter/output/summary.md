# Meeting summary

## Purpose

## What changed

## Confirmed decisions

## Key discussion

## Risks or blockers

## Open questions

## Next review point
