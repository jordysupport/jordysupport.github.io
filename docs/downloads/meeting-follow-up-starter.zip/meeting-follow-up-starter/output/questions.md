# Open questions

## Owner unclear

## Due date unclear

## Decision not finalized

## Conflicting statements

## Missing information

## Source-quality problems
