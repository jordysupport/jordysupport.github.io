# Evidence extraction

| Source location | Speaker | Statement | Label | Owner exactly stated | Due date exactly stated | Confidence | Ambiguity |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

## Items needing confirmation
-
