# Human review

- [ ] Processing the source is permitted.
- [ ] Unnecessary sensitive information was removed.
- [ ] Participants, date, project, and timezone are correct.
- [ ] Proposals were not converted into decisions.
- [ ] Owners accepted the tasks attributed to them.
- [ ] Due dates were not guessed.
- [ ] Disagreement and changing decisions are represented fairly.
- [ ] Ambiguous items appear under “Please confirm.”
- [ ] No recipients, links, attachments, or commitments were invented.
- [ ] The exact email draft was reviewed.
- [ ] No message, task, or calendar event was created without separate approval.
