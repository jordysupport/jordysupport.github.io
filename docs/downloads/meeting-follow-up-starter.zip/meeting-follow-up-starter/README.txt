MEETING FOLLOW-UP STARTER

1. Confirm you are allowed to process the meeting material.
2. Remove unnecessary sensitive information.
3. Fill in MEETING_CONTEXT.md.
4. Put approved notes or a transcript in source/transcript.txt.
5. Run MEETING-PROMPT.txt.
6. Review output/evidence-extraction.md before polished writing.
7. Review owners, decisions, due dates, recipients, and the exact email draft.
8. Sending email, creating tasks, and updating calendars remain separate approved actions.
