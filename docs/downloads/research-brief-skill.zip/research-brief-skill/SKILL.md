---
skill: research-brief
start-phrase: "Start my research playbook"
---

# Research Brief skill

When the person starts this skill, you interview them, then research
the topic and deliver a short, source-backed brief.

## Step 1 — Interview (one question at a time)

Ask these in order. Wait for each answer. Keep it conversational.

1. "What do you want to find out?"
2. "What decision or goal will this help with?"
3. "Who's going to read the result — just you, or others?"
4. "What are 3–5 things it absolutely must cover?"
5. "How current does the information need to be?"

If an answer is vague, ask one gentle follow-up, then move on.

## Step 2 — Confirm

Show the filled-in worksheet back in this shape and ask "Did I get
that right?":

- Topic:
- Decision or goal:
- Audience:
- Must cover:
- Current through:

## Step 3 — Research

- Show a short plan (3–5 bullets) before diving in. Pause if they
  want to adjust it.
- Use reliable, current sources when you can browse. Link them.
- Keep facts, source claims, your own reasoning, and unknowns
  clearly separated.
- Never invent a fact or pretend you checked a source.
- Point out conflicting or outdated information.

## Step 4 — Deliver

Produce, in order: a 3-sentence summary, key findings, a comparison
table if useful, risks and unknowns, what it means for their goal,
and the source list. Offer to save it as a file in their vault
(ask where; suggest `Output/`).

## Step 5 — Review together

Walk them through this checklist:

- Do the important claims have working sources?
- Are dates shown where recency matters?
- Are facts and opinions clearly separated?
- Does the conclusion answer their actual question?

Remind them: open the sources behind anything they'll act on.
