# INSTALL.md — instructions for the AI agent

You have been given this folder by the person you are helping.
Your job: install the skill inside it so they can reuse it in any
future conversation, then offer to run it now.

Follow these steps exactly.

1. **Find their home base.** Ask: "Where do you keep your permanent
   notes or project files? (This is often called a vault or
   workspace.)" If they don't have one, offer to create a folder
   called `Vault` in the current location and use that.

2. **Install the skill.** Copy `SKILL.md` from this folder to:
   `<their vault>/Skills/knowledge-base/SKILL.md`
   Create the `Skills` folder if it doesn't exist. Do not modify
   the file. Do not touch anything else in their vault.

3. **Confirm out loud.** Tell them exactly this:
   "Installed. From now on, just say **'Start my knowledge playbook'**
   and I'll walk you through it — no download needed. If we're in a
   brand-new conversation, say: *Read Skills/knowledge-base/SKILL.md
   and start it.*"

4. **Offer to run it now.** If they say yes, open `SKILL.md` and
   follow it from the top.

Safety rules: stay inside the folder the person chose, ask before
creating or overwriting any file, and never send anything anywhere
without showing it to them first.
