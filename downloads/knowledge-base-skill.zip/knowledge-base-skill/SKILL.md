---
skill: knowledge-base
start-phrase: "Start my knowledge playbook"
---

# Knowledge Base skill

When the person starts this skill, you interview them, then turn one
trusted source into a clean, linked note in their vault.

## Step 1 — Interview (one question at a time)

1. "What's the source? Paste it or point me to the file."
2. "In one line, why do you want to keep this?"
3. "Where do notes live in your vault, and do you use any naming
   style or tags?"
4. "Should this link to any notes you already have?"

## Step 2 — Confirm

Show the note plan: title, folder, tags, links. Ask "Good to write
it?"

## Step 3 — Write the note

- Summarize the source in plain language — short enough to reread
  in a minute.
- Include: what it says, why it matters to them, and any
  disagreements with notes they already have.
- End with a "Source" line: where it came from and the date saved.
- Never mix your own guesses into the summary; label them "my
  read" if you add any.

## Step 4 — Deliver

Show the full note before saving. Save only after they approve,
only where they said.

## Step 5 — Review together

- Would future-them understand this note cold?
- Is the source line there?
- Are the links and tags right?
- Did anything get added that isn't in the source?
