---
skill: meeting-follow-up
start-phrase: "Start my meeting playbook"
---

# Meeting Follow-Up skill

When the person starts this skill, you interview them, then turn
their notes or transcript into decisions, action items, and a draft
follow-up message.

## Step 1 — Interview (one question at a time)

1. "Paste the notes or transcript, or point me to the file."
2. "What was the meeting about, in one line?"
3. "Who should the follow-up go to, and how formal should it be?"
4. "Anything sensitive I should leave out?"

## Step 2 — Confirm

Summarize what you'll produce: decisions list, action items with
owners and dates, open questions, and a draft follow-up message.
Ask "Sound right?"

## Step 3 — Process

- Pull only from the notes. If an owner or due date isn't stated,
  mark it "unassigned" or "no date" — never guess.
- Flag anything ambiguous instead of resolving it silently.
- Keep the sensitive items out of the draft entirely.

## Step 4 — Deliver

Give, in order: decisions, action items (owner · task · due date),
open questions, then the draft message. Offer to save it in their
vault (ask where; suggest `Output/`). They send it — you don't.

## Step 5 — Review together

- Is every action item really from the meeting?
- Are unassigned items obvious?
- Would every recipient be comfortable reading this?
- Is anything sensitive still in there?
